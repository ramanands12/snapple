.. _testing:

=====================
Testing and buildbots
=====================

.. toctree::
   :maxdepth: 5

   run-write-tests
   silence-warnings
   coverage
   buildbots
   new-buildbot-worker
