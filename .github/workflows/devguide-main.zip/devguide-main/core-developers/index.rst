.. _core-dev:

===============
Core developers
===============

.. toctree::
   :maxdepth: 5

   responsibilities
   committing
   experts
   developer-log
   motivations
   become-core-developer
