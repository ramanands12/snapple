.. _garbage-collector:
.. _gc:
.. _garbage_collector:

========================
Garbage collector design
========================

.. highlight:: none

This document is now part of the
`CPython Internals Docs <https://github.com/python/cpython/blob/main/InternalDocs/garbage_collector.md>`_.
