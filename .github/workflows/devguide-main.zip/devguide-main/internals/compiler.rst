.. _compiler:

===============
Compiler design
===============

.. highlight:: none

This document is now part of the
`CPython Internals Docs <https://github.com/python/cpython/blob/main/InternalDocs/compiler.md>`_.
