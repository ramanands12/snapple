.. _interpreter:

========================
The bytecode interpreter
========================

This document is now part of the
`CPython Internals Docs <https://github.com/python/cpython/blob/main/InternalDocs/interpreter.md>`_.
