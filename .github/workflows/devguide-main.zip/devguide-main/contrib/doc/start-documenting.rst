===============
Getting started
===============

.. important::

   |draft|

   |purpose|


[This is the existing documentation :ref:`start-documenting` page from the devguide.]
