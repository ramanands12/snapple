=======================
reStructuredText markup
=======================

.. important::

   |draft|

   |purpose|


[This is the existing :ref:`markup` page from the devguide.]
