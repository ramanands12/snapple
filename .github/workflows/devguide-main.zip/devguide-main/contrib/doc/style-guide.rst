===========
Style guide
===========

.. important::

   |draft|

   |purpose|


[This is the existing documentation :ref:`style-guide` page from the devguide.]
