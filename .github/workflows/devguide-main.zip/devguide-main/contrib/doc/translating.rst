===========
Translating
===========

.. important::

   |draft|

   |purpose|


[This is the existing :ref:`translating` page from the devguide.]
