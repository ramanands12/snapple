==========================
Helping with documentation
==========================

.. important::

   |draft|

   |purpose|


[This is the existing :ref:`help-documenting` page from the devguide.]
