==================================
Helping with the Developer's Guide
==================================

.. important::

   |draft|

   |purpose|


[This is the existing :ref:`devguide` page from the devguide.]
