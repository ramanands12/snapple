.. important::

   |draft|

   |purpose|


=========
Core team
=========

[This is mostly re-organized from the :ref:`core-dev` section of the devguide,
but with "core developer" language changed to "core team" where possible.]

.. toctree::
   :maxdepth: 5

   responsibilities
   committing
   experts
   developer-log
   motivations
   join-team
