.. important::

   |draft|

   |purpose|


[This is the existing core developers :ref:`responsibilities` page from the devguide.  We'll
adjust "core developer" to "core team" where appropriate.]

.. include:: ../../core-developers/responsibilities.rst
