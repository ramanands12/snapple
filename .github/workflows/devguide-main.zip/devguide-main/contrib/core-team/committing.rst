.. important::

   |draft|

   |purpose|


[This is the existing core developers :ref:`committing` page from the devguide.  We'll
adjust "core developer" to "core team" where appropriate.]

.. include:: ../../core-developers/committing.rst
