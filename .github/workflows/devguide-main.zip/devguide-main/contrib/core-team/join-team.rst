.. important::

   |draft|

   |purpose|


[This is the existing core developers :ref:`become-core-developer` page from the devguide with the title changed.  We'll
adjust "core developer" to "core team" where appropriate.]

=========================
How to join the core team
=========================

.. include:: ../../core-developers/become-core-developer.rst
   :start-line: 7
