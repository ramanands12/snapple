.. important::

   |draft|

   |purpose|


[This is the existing core developers :ref:`experts` page from the devguide.  We'll
adjust "core developer" to "core team" where appropriate.]

.. include:: ../../core-developers/experts.rst
