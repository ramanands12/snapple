.. important::

   |draft|

   |purpose|


======================
Communication channels
======================

* Repos
* Discourse
* Discord
* Mailing lists (deprioritize)
* Where to get help
