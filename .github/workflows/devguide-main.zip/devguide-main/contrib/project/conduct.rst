===============
Code of Conduct
===============

.. important::

   |draft|

   |purpose|


[Brief summary of the code of conduct, with links to official source.]

* Standard for communication
* How to report
* Enforcement details
