.. important::

   |draft|

   |purpose|


[This is the existing :ref:`generative-ai` page from the devguide.]

.. include:: ../../getting-started/generative-ai.rst
