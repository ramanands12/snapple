.. important::

   |draft|

   |purpose|

======
GitHub
======

[Where are the actual artifacts?]

* Main CPython repos
* Core workflow repos
* Infrastructure repos
