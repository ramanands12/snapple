.. important::

   |draft|

   |purpose|


==========
Governance
==========

[How decisions are made, who is involved, how to participate.]

Steering Council
================

Documentation Editorial Board
=============================

Typing Council
==============


Others?
=======
