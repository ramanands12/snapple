=====
Roles
=====

.. important::

   |draft|

   |purpose|


[Quick overview of the roles people play.  Core team has its own section.]

* Core team
* Triager
* Contributors
   * types of contributions
