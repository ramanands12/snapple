.. _c_triage:

===================
Issues and triaging
===================

.. toctree::
   :maxdepth: 5

   issue-tracker
   triaging
   labels
   reviewing
   triage-team
