========
Git tips
========

.. important::

   |draft|

   |purpose|

[More git help for advanced things needed by code contributors.]
