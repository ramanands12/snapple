=====================
Testing and buildbots
=====================

.. important::

   |draft|

   |purpose|

[This is the existing :ref:`testing` page from the devguide.]

.. toctree::
   :maxdepth: 5

   ../../testing/run-write-tests
   ../../testing/silence-warnings
   ../../testing/coverage
   ../../testing/buildbots
   ../../testing/new-buildbot-worker
