==================
Setup and building
==================

.. important::

   |draft|

   |purpose|

[More setup and build instructions specifically for code contributors, building
on the basics from the :ref:`Getting Started <getting-started>` section.]
