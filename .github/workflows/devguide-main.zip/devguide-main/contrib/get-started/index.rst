.. _c_gettingstarted:

===============
Getting started
===============

.. important::

   |draft|

   |purpose|


* Basic setup
* Git bootcamp (simplified for everyone to use)
