.. _getting-started:

===============
Getting started
===============

.. toctree::
   :maxdepth: 5

   setup-building
   fixing-issues
   git-boot-camp
   pull-request-lifecycle
   getting-help
   generative-ai
